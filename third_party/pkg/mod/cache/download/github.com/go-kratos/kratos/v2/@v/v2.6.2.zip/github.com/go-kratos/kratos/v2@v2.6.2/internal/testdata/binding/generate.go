package binding

//go:generate protoc -I . --go_out=paths=source_relative:. ./test.proto
