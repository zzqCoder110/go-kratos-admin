# Metrics

## prometheus
```
go get -u github.com/go-kratos/kratos/contrib/metrics/prometheus/v2
```

## datadog
```
go get -u github.com/go-kratos/kratos/contrib/metrics/datadog/v2
```