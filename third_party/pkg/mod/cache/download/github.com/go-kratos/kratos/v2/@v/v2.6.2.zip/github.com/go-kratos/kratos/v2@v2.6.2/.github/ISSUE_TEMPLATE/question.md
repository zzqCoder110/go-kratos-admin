---
name: "\U0001F680 Question"
about: Ask a question about Kratos.
title: "[Question]"
labels: question
assignees: ''

---

Please see the FAQ in our main README.md before submitting your issue.
