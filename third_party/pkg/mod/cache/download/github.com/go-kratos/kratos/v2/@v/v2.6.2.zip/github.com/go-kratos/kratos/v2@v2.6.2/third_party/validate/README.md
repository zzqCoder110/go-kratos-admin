# protoc-gen-validate (PGV)

* https://github.com/envoyproxy/protoc-gen-validate
