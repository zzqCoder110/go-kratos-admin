# Kratos v2 Kit Design

MaoJian

Last updated: December 25, 2020

## Abstract
kratos v1 基础库主要专注在各类功能的细节实现，比如 gRPC 的负载均衡，熔断器等一系列微服务需要的功能。

## Background

## Proposal

## Implementation
