# encoding

## msgpack

```shell
go get -u github.com/go-kratos/kratos/contrib/encoding/msgpack/v2
```
